//
//  DeviceLockState.swift
//  CheckLockState
//
//

import Foundation

enum DeviceLockState {
    case locked
    case unlocked
}



