//
//  ViewController.swift
//  CheckLockState
//
//  Created by Joshua Boelman
//  Copyright © Cloutlabs. All rights reserved.
//

import UIKit
import Darwin
import AVKit
import AVFoundation
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate {
    
    var manager: CLLocationManager?
    var t = 0
    var i = 0
    var timesU = [String]();
    var timesL = [String]();
    var timesO = [String]();
    var dateL = [Date]();
    var dateU = [Date]();
    var durations = [Double]();
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        label.text = "ready"
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        manager = CLLocationManager()
        manager?.delegate = self
        if #available(iOS 14.0, *) {
            manager?.desiredAccuracy = kCLLocationAccuracyBest
        } else {
            manager?.desiredAccuracy = kCLLocationAccuracyKilometer
        }
        manager?.requestWhenInUseAuthorization()
        manager?.startUpdatingLocation()
        manager?.allowsBackgroundLocationUpdates = true
    }
    
    func locationManager(_ manager: CLLocationManager,didUpdateLocations locations: [CLLocation]){
        guard let first = locations.first else {
            return
        }
        label.text = " Longitute : \(first.coordinate.longitude) \n | Latitude :  \(first.coordinate.latitude)"
    }
    
    @IBOutlet var label: UILabel!
    
    
    var backgroundTaskID: UIBackgroundTaskIdentifier!
    
    @IBAction func actionButtonTapped(_ sender: UIButton) {
        if(sender.tag == 0){
        print("clocked in")
       runBackgroundCheck()
        }else{
        exit(0)
        }
    }
    
    
    func runBackgroundCheck(){
        var timer = Timer.scheduledTimer(timeInterval: 1.0,
                                                               target: self,
                                                               selector: #selector(checkState),
                                                               userInfo: nil,
                                                               repeats: true)
    }
  
    func showPhoneState(_ deviceLockState: DeviceLockState) {
        
        let now = Date()
        
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .medium
        let dateTimeU = formatter.string(from: now)
        
        switch deviceLockState {
        case .locked:
            //print("locked")
            if (t == 1){
                print(now - 11.83, " ---  Locked.")
                let dateTimeL = formatter.string(from: now - 11.83)
                timesL.append(dateTimeL)
                dateL.append(now - 11.83)
                durations.append(dateL[i].timeIntervalSince(dateU[i]))
                i += 1;
            }
            t = 0
        case .unlocked:
            //print("Unlocked")
            if (t == 0){
                print(now, " ---  Unlocked." )
                timesU.append(dateTimeU)
                dateU.append(now)
            }
            t = 1
        }
        
    }
    
    
    @IBAction func Clockout(_ sender: UIButton) {
        if(sender.tag == 1){
            print("Clocked out")
            print("           ")
            print("    --Unlocked--                     --Locked--                  --Duration--  ")
            
          
            for(U,(L,D)) in zip(timesU,zip(timesL,durations)){
                print("\(U)     -     \(L)     -     \(D)")
                }
        }
    }
    
    var end = 0;
    
    
    @objc func checkState(){
        DispatchQueue.global().asyncAfter(deadline: .now() + 1) {[weak self] in
            Utility.checkDeviceLockState() {
                lockState in
                if let self = self {
                    self.showPhoneState(lockState)
                }
            }
        }
     
    }
    
    @objc func endBack(){
        
        UIApplication.shared.endBackgroundTask(self.backgroundTaskID)
        backgroundTaskID = UIApplication.shared.beginBackgroundTask()
    }
    
    @IBAction func onUploadTapped(){
        
        
    }
    
    @IBAction func onShowTapped(){
        
    }
    

}

